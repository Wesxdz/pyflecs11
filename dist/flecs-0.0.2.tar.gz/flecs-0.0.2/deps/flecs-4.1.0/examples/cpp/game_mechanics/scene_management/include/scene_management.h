#ifndef SCENE_MANAGEMENT_H
#define SCENE_MANAGEMENT_H

/* This generated file contains includes for project dependencies */
#include "scene_management/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

