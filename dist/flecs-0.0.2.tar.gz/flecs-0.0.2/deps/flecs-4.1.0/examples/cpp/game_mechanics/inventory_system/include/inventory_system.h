#ifndef INVENTORY_SYSTEM_H
#define INVENTORY_SYSTEM_H

/* This generated file contains includes for project dependencies */
#include "inventory_system/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

