#ifndef AUTO_DEFINE_ENUM_H
#define AUTO_DEFINE_ENUM_H

/* This generated file contains includes for project dependencies */
#include "auto_define_enum/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

