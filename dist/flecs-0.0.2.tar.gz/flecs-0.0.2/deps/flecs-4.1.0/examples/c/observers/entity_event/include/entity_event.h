#ifndef ENTITY_EVENT_H
#define ENTITY_EVENT_H

/* This generated file contains includes for project dependencies */
#include "entity_event/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

