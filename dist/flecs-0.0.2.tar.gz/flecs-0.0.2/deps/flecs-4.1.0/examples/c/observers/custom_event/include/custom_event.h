#ifndef CUSTOM_EVENT_H
#define CUSTOM_EVENT_H

/* This generated file contains includes for project dependencies */
#include "custom_event/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

