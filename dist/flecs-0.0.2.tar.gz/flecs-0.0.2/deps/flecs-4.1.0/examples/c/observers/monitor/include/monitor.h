#ifndef MONITOR_H
#define MONITOR_H

/* This generated file contains includes for project dependencies */
#include "monitor/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

