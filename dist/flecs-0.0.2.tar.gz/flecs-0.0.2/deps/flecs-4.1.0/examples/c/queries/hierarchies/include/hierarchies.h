#ifndef HIERARCHIES_H
#define HIERARCHIES_H

/* This generated file contains includes for project dependencies */
#include "hierarchies/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

