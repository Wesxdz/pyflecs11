#ifndef SETTING_VARIABLES_H
#define SETTING_VARIABLES_H

/* This generated file contains includes for project dependencies */
#include "setting_variables/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

