#ifndef ITER_TARGETS_H
#define ITER_TARGETS_H

/* This generated file contains includes for project dependencies */
#include "iter_targets/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

