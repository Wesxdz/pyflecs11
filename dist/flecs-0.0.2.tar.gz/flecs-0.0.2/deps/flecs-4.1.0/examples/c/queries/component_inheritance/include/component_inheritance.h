#ifndef COMPONENT_INHERITANCE_H
#define COMPONENT_INHERITANCE_H

/* This generated file contains includes for project dependencies */
#include "component_inheritance/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

