#ifndef SCRIPT_MANAGED_H
#define SCRIPT_MANAGED_H

/* This generated file contains includes for project dependencies */
#include "script_managed/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

