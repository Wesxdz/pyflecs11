#ifndef SCRIPT_W_VARS_H
#define SCRIPT_W_VARS_H

/* This generated file contains includes for project dependencies */
#include "script_w_vars/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

