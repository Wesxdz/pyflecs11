#ifndef FUNCTIONS_H
#define FUNCTIONS_H

/* This generated file contains includes for project dependencies */
#include "functions/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

