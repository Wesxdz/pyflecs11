#ifndef SYNC_POINT_DELETE_H
#define SYNC_POINT_DELETE_H

/* This generated file contains includes for project dependencies */
#include "sync_point_delete/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

