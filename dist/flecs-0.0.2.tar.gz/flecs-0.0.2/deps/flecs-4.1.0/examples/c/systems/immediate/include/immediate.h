#ifndef IMMEDIATE_H
#define IMMEDIATE_H

/* This generated file contains includes for project dependencies */
#include "immediate/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

