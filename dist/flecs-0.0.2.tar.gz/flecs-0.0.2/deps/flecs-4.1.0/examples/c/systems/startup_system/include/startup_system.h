#ifndef STARTUP_SYSTEM_H
#define STARTUP_SYSTEM_H

/* This generated file contains includes for project dependencies */
#include "startup_system/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

