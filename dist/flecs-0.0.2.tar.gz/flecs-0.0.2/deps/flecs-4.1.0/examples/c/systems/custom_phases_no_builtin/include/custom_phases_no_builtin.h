#ifndef CUSTOM_PHASES_NO_BUILTIN_H
#define CUSTOM_PHASES_NO_BUILTIN_H

/* This generated file contains includes for project dependencies */
#include "custom_phases_no_builtin/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

